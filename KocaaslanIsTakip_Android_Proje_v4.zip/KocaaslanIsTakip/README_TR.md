# Kocaaslan İş Takip

Yavuz Kocaaslan ve Kocaaslan Kantin için hazırlanmış, internetsiz çalışan native Android ciro/gider ve kâr-zarar takip uygulaması.

## Özellikler

- İki işletme için birbirinden ayrı kayıtlar
- Gelir ve gider girişi
- Günlük, haftalık ve aylık gelir / gider / net kâr-zarar
- Gelir ve gider kategorileri
- Son 6 aylık grafik
- Arama ve dönem filtreleme
- CSV dışa aktarma (Excel ile açılabilir)
- JSON yedekleme ve geri yükleme
- İsteğe bağlı 4 haneli PIN kilidi
- SQLite ile cihazda yerel veri saklama
- Tablet kullanımına uygun büyük, renkli arayüz

## APK

Bu proje, `.github/workflows/build-apk.yml` dosyası sayesinde GitHub Actions üzerinden otomatik olarak kurulabilir APK üretir. Ayrıntılı adımlar için `APK_OLUSTURMA_REHBERI.md` dosyasına bakın.


## Sürüm 1.1.0
- Genel Toplam kartı eklendi: ilk kayıttan bugüne toplam gelir, gider ve net kâr/zarar.
